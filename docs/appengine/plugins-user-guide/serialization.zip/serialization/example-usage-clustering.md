---
sidebar_position: 3
---

# Example Usage: Clustering

This page outlines the process of clustering items based on the SEC standard and provides an overview of serialization and track & trace procedures, as well as examples of transactions in Warehouse Management Systems (WMS) using serial numbers (SN).

---

## SEC Standard

The SEC (Single European Coding) standard serves as a unique identifier for marking human tissues and cells distributed within the European Union. As of April 29, 2017, SEC is a mandatory requirement for all tissue establishments (TEs) in the EU.

The SEC standard consists of two primary elements:
    - SEC-DI: A 21-character unique identifier for the donation.
    - SEC-PI: A 19-character product identification sequence.

![Single European Coding](./media/clustering/image2020-1-8-13-19-3.png)

The SEC code includes several components:
    - **ISO Country Identifier** - identifies the country of the TE issuing the SEC. The code used is the ISO 3166-1 alpha-2 country identifier
    - **TE Code**: Tissue Establishment code of the manufacturer creating products out of the received human tissue. TEs are listed in the EU Tissue Establishment Compendium
    - **Unique Donation Number**: identifies an individual donor
    - **Coding System Identifier**: Identifies the system from the Product Code is derived. So far in the EU the following three coding systems are used:

        | ***Coding System*** | ***Identifier*** |
        | --- | --- |
        | ISBT 128 | A|
        | Eurocode | B | 
        | EUTC | E | 

    - **Product Code** - Identifies the product created from the donated tissue
    - **Split number** - Uniquely identifies each produced product within the Donation Identification and Product Code combination.
    - **Expiry Date** - Expiry date of the created/produced product in YYYYMMDD format.

## Clustering

In a Goods Receipt PO, both Supplier Batch Numbers and Supplier Serial Numbers are recorded, and internal batch numbers are generated. The Receiver requires different scenario groups for Internal Batch number generation. The received items are clustered into Internal Batch numbers based on scenario group identifiers such as: same Item, same PO, same supplier DN/PL, same Supplier Batch, same Expiry Date.

It is essential to define specific clustering identifiers for each organization, Item group, and Item. For example, for Receiver 1, the clustering of received products into a single Internal Batch number is based on a unique combination of Item, PO, PackList, and Supplier Batch. For Receiver 2, clustering might depend on a combination of Item, PO, PackList, and Expiry Date. If all these elements match, the same Internal Batch number can be assigned to the received product.

Since Supplier Serial numbers are only unique within a specific UDI Lot number and multiple Lots may be received on a single PO-line, the serial number registration must not only link to the Internal Batch but also to the Supplier Batch.

The following example illustrates how Internal Batches from one company (the Supplier) are received by another company (the Receiver) and the factors that determine clustering into a single Internal Batch.

    ![Batch Clustering](./media/clustering/batch-clustering.jpg)

**Clustering rule**:

| ***GRPO type*** | ***DN/PL # supplier*** | ***PO*** | ***Item*** | ***Supplier Batch #*** | ***Expiry Date*** |
| --- | --- | --- | --- | --- | --- |
| Receiver SEC/Serial# GRPO | Y | Y | Y |  | Y |

### Item Declaration for Serialization

To enable serialization for items managed by Batch, set the UDF "Serialization enabled" to "Yes" in the Item Master Data. This setting ensures that all revisions of the item are governed by rules that control the selection of the Serialization Parameter Template (SPT) for each item revision.

![Clustering](./media/clustering/image2020-1-8-13-57-39.png)

### WEB Application – log in

[Please check this section of the documentation](/docs/appengine/appengine-users-guide/launchpad/) to know more about web application.

### Attributes Templates – Definition

The initial step is to define Attribute Templates, which will be used to create different variants of the Serialization Parameter Template (SPT). Each UNP member is assigned a unique Attribute. Additionally, it is important to define Attributes that facilitate the execution of the clustering process.

![Clustering - Attribute Templates](./media/clustering/image2020-1-9-10-13-41.png)
![Clustering - Attribute Templates](./media/clustering/attribute-templates-h.png)

Below is the list of attributes based on the SEC standard, along with other attributes needed for the clustering process. To ensure clustering follows a defined rule, you must configure attributes as specified in the list:

![Clustering - Attributes Definition](./media/clustering/list-of-attributes.png)

**SEC Standard – donation identification**:

![SEC Standard – Donation Identification](./media/clustering/sec-standard-donation-identification.png)

**SEC Standard – product identification**:

![SEC Standard – Product Identification](./media/clustering/2020-11-13-11-49-00.png)
![SEC Standard – Product Identification](./media/clustering/Batch.png)

**Clustering components**:

![Clustering Components](./media/clustering/2020-11-13-11-44-59.png)
![Clustering Components](./media/clustering/exp-date.png)

SEC Serial Number component is obligatory and is a key to Track & Trace Table:

![Clustering - SEC Serial Number Component](./media/clustering/sec-serial-number-component.png)

By default, clustering is sensitive to changes in the Item. Additional parameters to which clustering is sensitive are determined at the Attribute level. The parameters for which Clustering ID = Yes include: SEC - Purchase Order, SEC - Delivery Note, and SEC - Expiry Date.

![Clustering - Attribute Templates](./media/clustering/attribute-templates-expiry-date.png)

---

For field description please check [here](/docs/appengine/plugins-user-guide/serialization/fields-description#attribute-templates)

### Serialization Parameters Templates – definition

Attributes linked to the Serialization Parameter Template (SPT) serve as parameters for the rules that govern the application of a specific SPT for clustering a given Item. The SPT is created by combining previously defined attribute templates, and users can modify the parameters of these attributes. When defining an SPT, it is necessary to assign each attribute to a predefined field in the Track & Trace Table, ensuring the field type is compatible with the attribute's type. This process enables the creation of a dedicated Track & Trace Table for each Item, based on the defined SPT.

![Clustering - Serialization Parameters Templates](./media/clustering/image2020-1-9-12-20-23.png)
![Clustering - Serialization Parameters Templates](./media/clustering/image2020-1-9-12-21-51.png)

Please create a new Serialization Parameter Template (SPT) and incorporate the predefined Attribute Templates, assigning them to the corresponding predefined fields in the Track & Trace Table.

![Clustering - Serialization Parameters Templates](./media/clustering/serialization-parameters-templates.png)

---

### Rules – definition

To initiate the clustering process for a specific Item/Revision, it is essential to define at least one Rule that applies to the Item.

![Clustering](./media/clustering/image2020-1-9-12-54-7.png)

If the Rule specifies only the Item Group, the SPT selected in the Result SPT column will be applied to all Items in that Group. If the Item Code is specified, the Result SPT will apply to all revisions of the Item. If a specific revision of the Item is provided, the Result SPT will be applied only to that revision. This applies to Items with the UDF "Serialization enabled" set to "Yes" in the Item Master Data. In our example, we will define a rule that ensures the previously defined SPT is applied to all revisions of a given Item.

![Clustering](./media/clustering/image2020-1-9-12-52-22.png)

### Start the clustering process

The clustering process is stored in a serialization document, which undergoes approval and verification. Serialization documents can be viewed in the WMS's Packing Hierarchy tile.: [here](/docs/appengine/plugins-user-guide/serialization/fields-description#serialization-results).

For testing, you can use the scanner simulator provided here: [WMSScannerSimulator.exe](https://download.computec.one/software/wms/tools/WMS_Scanning_Simulator.exe).

Sample test data is available in the attached file: [SEC Clustering Test Case 09.01.2020 - 01.xlsx.](https://download.computec.one/software/wms/tools/SEC_Clustering_Test_Case.xlsx).

Attributes with a defined GS1-ID must be prefixed with the ID in the simulator. For example, the SEC - Purchase Order should be preceded by (99).

![Clustering](./media/clustering/image2020-1-9-14-58-21.png)

Enable Serialization in CompuTec WMS (check [here](/docs/appengine/plugins-user-guide/serialization/serialization-plugin-installation-and-configuration#computec-wms)). Log in to CompuTec WMS (check [here](/docs/wms/user-guide/starting/)).

Start Serialisation Document:

![Clustering](./media/clustering/image2020-1-15-12-19-29.png)![Clustering](./media/clustering/image2020-1-9-15-38-42.png)
![Clustering](./media/clustering/screenshot-2.png)![Clustering](./media/clustering/image2020-1-9-15-4-52.png)

Start scanning data for the first serial number:

    1. Purchase Order.
    2. Delivery Note.
    3. Serial Number.
    4. Supplier Batch.

After scanning the data of the first serial number you will be redirected to scan the next one.

(You can also choose the New Goods Receipt option to receipt goods serialized Items without a Purchase Order)

If you want to cancel scanning, select "tick mark"", and then "cross mark" . You will be able to return to this document.

![Clustering](./media/clustering/image2020-1-9-15-20-38.png)
![Clustering](./media/clustering/image2020-1-9-15-24-52.png)

Return to editing the serialization document.

![Clustering](./media/clustering/image2020-1-9-15-38-1.png)
![Clustering](./media/clustering/image2020-1-15-12-27-40.png)

Continue scanning serial numbers.vTo finish the serialization document, select "tick mark", and then "save".

**Deleting SN in CompuTec WMS**

When receiving a serialized item, the serial number (SN) is generated automatically during the GRPO scanning process. If an employee identifies that the item was received under the wrong PO or Pack List, it can be deleted.

![Clustering](./media/clustering/delete-serial-number.png)

    1. Clear Common Fields.
    2. Clear SU List.
    3. Delete Serial Numbers.

### Check serialisation document

The unfinished document is in Open status. The finished document is in the status of Ready To Accept. The document has to be accepted for further processing. Document in status Ready To Accept can be edited to make corrections. To do this, go to the WEB application and select:

![Clustering](./media/clustering/image2020-1-915-59-50.png)
![Clustering](./media/clustering/image2020-1-9-16-55-31.png)

Add or remove batch – RMBM option on batch line:

![Clustering](./media/clustering/image2020-1-9-17-8-8.png)

Change of SN assignment to batch:

![Clustering](./media/clustering/image2020-1-9-17-8-59.png)

Finally, accept the serialization document:

![Clustering](./media/clustering/image2020-1-9-17-10-24.png)

Once accepted, the status of the document changes to Verification.

![Clustering](./media/clustering/image2020-1-9-17-20-8.png)

### Verification Document

The accepted serialization document is subject to verification in WMS:

![Clustering](./media/clustering/image2020-1-9-17-13-43.png)![Clustering](./media/clustering/image2020-1-15-12-51-44.png) ![Clustering](./media/clustering/image2020-1-9-17-14-54.png)

To confirm verification, select "save".

The document status changes to Closed which is visible in the WEB application in the document list.

![Clustering](./media/clustering/image2020-1-9-17-30-36.png)

### Receipt Document

Go to Receipt Document and enter Vendor, Warehouse and Bin Location (if applicable) and optionally Remarks, and then select "save". The GRPO document is saved and is now visible in SAP Business One.

![Clustering](./media/clustering/image2020-1-9-17-21-28.png)![Clustering](./media/clustering/image2020-1-15-12-51-44-1.png) ![Clustering](./media/clustering/image2020-1-9-17-25-51.png)

Goods Receipt PO in SAP Business One:

![Clustering](./media/clustering/goods-receipt-po-in-sapb1.png)

Batch Number Transactions Report:

![Clustering](./media/clustering/batch-no-transaction-report.png)

### Track & Trace Report

![Clustering](./media/clustering/track-trace.png)

By selecting Track & Trace Report in the WEB application, it is possible to trace the Serial Number history:

![Clustering](./media/clustering/serial-no.png)
![Clustering](./media/clustering/serial-no-1.png)

## Example transactions in WMS using SN

### Stock Transfer

Source Warehouse selection

![Clustering](./media/clustering/stock-transfer.png)![Clustering](./media/clustering/transfer-operations.png)![Clustering](./media/clustering/warehouse-3.png)

Item selection

![Clustering](./media/clustering/document-details-7.png)![Clustering](./media/clustering/new-item-3.png)

Batch and quantity to transfer selection

![Clustering](./media/clustering/document-details-6.png)![Clustering](./media/clustering/options.png)![Clustering](./media/clustering/batches-7.png)![Clustering](./media/clustering/quantity-4.png)

Serial numbers to transfer selection

![Clustering](./media/clustering//search-serialization-4.png)![Clustering](./media/clustering/search-serialization-3.png)![Clustering](./media/clustering/quantity-5.png)

Destination warehouse selection

![Clustering](./media/clustering/document-details-5.png)![Clustering](./media/clustering/destination-warehouse.png)

Items confirmation and transfer document confirmation

![Clustering](./media/clustering/put-items.png)![Clustering](./media/clustering/remarks-4.png)

### Goods Issue

Warehouse selection

![Clustering - Warehouse Selection](./media/clustering/warehouse-1.png)![Clustering - Warehouse Selection](./media/clustering/warehouse-2.png)

#### Item selection

![Clustering - Item Selection](./media/clustering/document-details-4.png)![Clustering - Item Selection](./media/clustering/new-item-4.png)

#### Batch and quantity selection

![Clustering - Batch and Quantity Selection](./media/clustering/document-details-2.png)![Clustering - Batch and Quantity Selection](./media/clustering/batches-1.png)
![Clustering - Batch and Quantity Selection](./media/clustering/quantity-2.png)

#### Serial numbers selection

![Clustering - Serial Numbers Selection](./media/clustering/image2020-1-13-11-9-2.png)![Clustering - Serial Numbers Selection](./media/clustering/image2020-1-13-11-43-57.png)
![Clustering - Serial Numbers Selection](./media/clustering/image2020-1-13-11-22-38.png)

#### Issue document confirmation

![Clustering - Issue Document Confirmation](./media/clustering/document-details-1.png)![Clustering - Issue Document Confirmation](./media/clustering/remarks.png)

### Delivery

#### Warehouse selection

![Clustering - Warehouse Selection](./media/clustering/delivery.png)![Clustering](./media/clustering/delivery-1.png)
![Clustering - Warehouse Selection](./media/clustering/warehouse.png)

#### Customer selection

![Clustering - Customer Selection](./media/clustering/customer-selection.png)

#### Item selection

![Clustering - Item Selection](./media/clustering/document-details.png)![Clustering - Item Selection](./media/clustering/new-item.png)

#### Batch and quantity selection

![Clustering - Batch and Quantity Selection](./media/clustering/image2020-1-13-11-2-10.png)![Clustering - Batch and Quantity Selection](./media/clustering/image2020-1-13-12-8-18.png)
![Clustering - Batch and Quantity Selection](./media/clustering/batches.png)![Clustering - Batch and Quantity Selection](./media/clustering/quantity-1.png)

#### Serial number selection

![Clustering - Serial Number Selection](./media/clustering/search-serialization.png)![Clustering - Serial Number Selection](./media/clustering/search-serialization-1.png)
![Clustering - Serial Number Selection](./media/clustering/quantity.png)![Clustering - Serial Number Selection](./media/clustering/storage-info.png)

#### Delivery document confirmation

![Clustering - Delivery Document Confirmation](./media/clustering/document-details-3.png)![Clustering - Delivery Document Confirmation](./media/clustering/image2020-1-13-12-27-46.png)
