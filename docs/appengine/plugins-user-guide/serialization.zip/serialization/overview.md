---
sidebar_position: 1
---

# Overview

The installation section provides additional information that complements the standard plug-in installation process, enabling the use of serialization in CompuTec WMS and ProcessForce.

In the Field Description section, you can find a comprehensive explanation of the serialization configuration in the WEB application. This configuration allows serialization to be carried out in accordance with various standards and process scenarios, such as clustering.

The Example Usage section offers a step-by-step guide for an example clustering process, beginning with the configuration in the WEB application, followed by the clustering process in CompuTec WMS, and concluding with the basic transactions in CompuTec WMS using serial numbers (SN) ending. This section is the ideal starting point.
