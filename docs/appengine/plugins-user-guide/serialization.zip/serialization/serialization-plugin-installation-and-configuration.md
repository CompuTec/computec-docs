---
sidebar_position: 2
---

# Serialization Plugin Installation and Configuration

The standard plugin installation and configuration is described in the AppEngine documentation [here](../../administrators-guide/configuration-and-administration/configuration.md).

Here you can find information about additional action that you have to take on top of the standard plugin installation be able to fully use the Serialization plugin.
Please remember to install versions of the components according to the version table available [here](../../releases/appengine/download.md).

---

## Prerequisites

:::caution
Before beginning the installation of the serialization plugin, ensure that both ProcessForce and the CompuTec License Server are properly installed and configured. For further guidance on the installation process, click [here](/docs/processforce/administrator-guide/licensing/license-server/overview).
:::

Ensure CompuTec WMS is installed and configured. To install and configure CompuTec WMS, refer to the following links:

- [Installation](https://learn.computec.one/docs/wms/administrator-guide/installation/requirements)
- [Custom Configuration](https://learn.computec.one/docs/wms/administrator-guide/custom-configuration/overview).

## AppEngine and Serialization Plugin Installation and Configuration

For AppEngine installation, please follow this link: [Installation](/docs/appengine/administrators-guide/installation/).

For plugin installation please refer to this [Configuration and Administration](/docs/appengine/administrators-guide/configuration-and-administration/overview/) page.

>**Note**: After updating the Serialization plugin and restarting the App Engine, remember to update the schema as per the procedure here.

## Enabling Serialization

### CompuTec WMS

- Enter the CompuTec AppEngine address (10) in the [WMS Server](/docs/wms/administrator-guide/installation/wms-server/overview/) settings:

    ![CompuTec AppEngine Address (in WMS server settings)](./media/serialization/wms-settings.png)

- Enable Serialization in the [Custom Configuration](/docs/wms/administrator-guide/custom-configuration/overview/) settings:

    ![Serialization](./media/serialization/image2020-1-14-16-40-22.png)

- Customize the main menu options to include the Serialization workflow. To do this, please follow Custom Config Function: [Manager](/docs/wms/administrator-guide/custom-configuration/custom-configuration-functions/manager/overview/) and sub-function: [Interface Design Manager](/docs/wms/administrator-guide/custom-configuration/custom-configuration-functions/manager/interface-design-manager):

    ![Serialization](./media/serialization/image2020-1-14-16-51-11.png)

### ProcessForce

- Optionally, the Serialization plugin can be triggered from within ProcessForce.

    ![Serialization Plugin (from inside the ProcessForce)](./media/serialization/image2020-1-18-8-44-13.png)

- To enable this, check the appropriate checkbox

    ![Serialization Plugin (from inside the ProcessForce)](./media/serialization/image2020-1-18-8-33-41.png)

- Enter the AppEngine URL (e.g., `http://{host}:54000`)
- Click Update and restart SAP Business One to complete the configuration.

---
 By following these installation and configuration steps, users will successfully integrate the Serialization plugin into CompuTec WMS and ProcessForce. This will enable efficient serialization management and ensure compatibility with SAP Business One. Ensure that all components are updated according to the version table for optimal performance.
